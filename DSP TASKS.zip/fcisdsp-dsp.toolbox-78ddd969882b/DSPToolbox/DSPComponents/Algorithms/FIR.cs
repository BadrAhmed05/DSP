﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class FIR : Algorithm
    {
        public Signal InputTimeDomainSignal { get; set; }
        public FILTER_TYPES InputFilterType { get; set; }
        public float InputFS { get; set; }
        public float? InputCutOffFrequency { get; set; }
        public float? InputF1 { get; set; }
        public float? InputF2 { get; set; }
        public float InputStopBandAttenuation { get; set; }
        public float InputTransitionBand { get; set; }
        public Signal OutputHn { get; set; }
        public Signal OutputYn { get; set; }
        private List<float> Wlist = new List<float>();
        private List<float> Hlist = new List<float>();
        float fc = 0, fc1 = 0, fc2 = 0;

        public override void Run()
        {
            if (InputFilterType == FILTER_TYPES.LOW)
                Hlist = Low();
            else if (InputFilterType == FILTER_TYPES.HIGH)
                Hlist = High();
            else if (InputFilterType == FILTER_TYPES.BAND_PASS)
                Hlist = PassBand();
            else if (InputFilterType == FILTER_TYPES.BAND_STOP)
                Hlist = StotBand();

            Hlist.Reverse();
            for (int i = Wlist.Count - 2; i >= 0; i--)
                Hlist.Add(Hlist[i]);

            OutputHn = new Signal(Hlist, Indeces(Hlist.Count), false);
            DirectConvolution conv = new DirectConvolution();
            conv.InputSignal1 = InputTimeDomainSignal;
            conv.InputSignal2 = OutputHn;
            conv.Run();
            OutputYn = conv.OutputConvolvedSignal;
        }

        private List<float> Window()
        {
            int Out;
            if (InputStopBandAttenuation <= 21)
            {
                Out = CalcNum(0.9f);
                Wlist = Rectangler(Out);
            }
            else if (InputStopBandAttenuation <= 44)
            {
                Out = CalcNum(3.1f);
                Wlist = Hanning(Out);
            }
            else if (InputStopBandAttenuation <= 53)
            {
                Out = CalcNum(3.3f);
                Wlist = Hamming(Out);
            }
            else if (InputStopBandAttenuation <= 74)
            {
                Out = CalcNum(5.5f);
                Wlist = Blackman(Out);
            }
            return Wlist;
        }

        private List<float> Rectangler(int N)
        {
            for (int i = 0; i < N; i++)
                Wlist.Add(1);
            return Wlist;
        }

        private List<float> Hanning(int N)
        {
            for (int i = 0; i <= (N / 2); i++)
                Wlist.Add(0.5f + (0.5f * (float)Math.Cos((2 * Math.PI * i) / N)));
            return Wlist;
        }

        private List<float> Hamming(int N)
        {
            for (int i = 0; i <= (N / 2); i++)
                Wlist.Add(0.54f + (0.46f * (float)Math.Cos(((float)Math.PI * 2 * i) / N)));
            return Wlist;
        }

        private List<float> Blackman(int N)
        {
            for (int i = 0; i <= (N / 2); i++)
                Wlist.Add(0.42f + (0.5f * (float)Math.Cos((2 * Math.PI * i) / (N - 1))) + (0.08f * (float)Math.Cos((4 * Math.PI * i) / (N - 1))));
            return Wlist;
        }

        private int CalcNum(float wsize)
        {
            int N = (int)(wsize / (InputTransitionBand / InputFS));
            return (N % 2) == 0 ? N + 1 : N;
        }

        private List<int> Indeces(int N)
        {
            List<int> index = new List<int>();
            for (int i = -(N / 2); i <= N / 2; i++)
                index.Add(i);
            return index;
        }
        private List<float> High()
        {
            fc = (float)(InputCutOffFrequency - (InputTransitionBand / 2)) / InputFS;
            Wlist = Window();
            Hlist.Add((1 - (2 * fc)) * Wlist[0]);
            for (int i = 1; i < Wlist.Count; i++)
                Hlist.Add((Wlist[i] * -(2 * fc) * (float)(Math.Sin((Math.PI * 2 * fc) * i) / ((Math.PI * fc * 2) * i))));

            return Hlist;
        }
        private List<float> Low()
        {
            fc = (float)(InputCutOffFrequency + (InputTransitionBand / 2)) / InputFS;
            Wlist = Window();
            Hlist.Add(2 * fc * Wlist[0]);
            for (int i = 1; i < Wlist.Count; i++)
                Hlist.Add(Wlist[i] * ((2 * fc) * (float)(Math.Sin((Math.PI * 2 * fc) * i) / ((Math.PI * fc * 2) * i))));

            return Hlist;
        }
        private List<float> PassBand()
        {
            fc1 = (float)(InputF1 - (InputTransitionBand / 2)) / InputFS;
            fc2 = (float)(InputF2 + (InputTransitionBand / 2)) / InputFS;
            Wlist = Window();
            Hlist.Add(2 * (fc2 - fc1) * Wlist[0]);
            for (int i = 1; i < Wlist.Count; i++)
                Hlist.Add((Wlist[i] * ((2 * fc2) * (float)(Math.Sin((Math.PI * 2 * fc2) * i) / ((Math.PI * fc2 * 2) * i)) - (2 * fc1) * (float)(Math.Sin((Math.PI * 2 * fc1) * i) / ((Math.PI * fc1 * 2) * i)))));

            return Hlist;
        }
        private List<float> StotBand()
        {
            fc1 = (float)(InputF1 + (InputTransitionBand / 2)) / InputFS;
            fc2 = (float)(InputF2 - (InputTransitionBand / 2)) / InputFS;
            Wlist = Window();
            Hlist.Add((1 - (2 * (fc2 - fc1))) * Wlist[0]);
            for (int i = 1; i < Wlist.Count; i++)
                Hlist.Add((Wlist[i] * ((2 * fc1) * (float)(Math.Sin((Math.PI * 2 * fc1) * i) / ((Math.PI * fc1 * 2) * i)) - (2 * fc2) * (float)(Math.Sin((Math.PI * 2 * fc2) * i) / ((Math.PI * fc2 * 2) * i)))));

            return Hlist;
        }
    }
}