﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class DirectCorrelation : Algorithm
    {
        public Signal InputSignal1 { get; set; }
        public Signal InputSignal2 { get; set; }
        public List<float> OutputNonNormalizedCorrelation { get; set; }
        public List<float> OutputNormalizedCorrelation { get; set; }
        public List<float> signal1 = new List<float>();
        public List<float> signal2 = new List<float>();

        public void crossOrauto()
        {
            if (InputSignal2 == null)
            {

                signal1 = InputSignal1.Samples;
                for (int i = 0; i < InputSignal1.Samples.Count; i++)
                {
                    signal2.Add(InputSignal1.Samples[i]);
                }
            }
            else
            {
                signal1 = InputSignal1.Samples;
                signal2 = InputSignal2.Samples;
            }
        }
        public void checkSize()
        {
            if (signal1.Count != signal2.Count)
            {
                int outputLength = signal1.Count + signal2.Count - 1;
                for (int i = signal1.Count; i < outputLength; i++)
                    signal1.Add(0);
                for (int i = signal2.Count; i < outputLength; i++)
                    signal2.Add(0);
            }
        }
        public double getNormalization()
        {
            double normalization = 0, signal1_sum = 0, signal2_sum = 0;
            for (int i = 0; i < signal1.Count; i++)
            {
                signal1_sum += Math.Pow(signal1[i], 2);
                signal2_sum += Math.Pow(signal2[i], 2);
            }
            normalization = signal1_sum * signal2_sum;
            normalization = Math.Pow(normalization, 0.5);
            return normalization / signal1.Count;
        }
        public override void Run()
        {

            OutputNonNormalizedCorrelation = new List<float>();
            OutputNormalizedCorrelation = new List<float>();
            List<float> correlation = new List<float>();


            crossOrauto();
            checkSize();
            double normalization = getNormalization();

            if (InputSignal1.Periodic == true)
            {
                for (int i = 0; i < signal2.Count; i++)
                {
                    double sum = 0;
                    if (i == 0)
                    {
                        for (int j = 0; j < signal2.Count; j++)
                            sum += signal1[j] * signal2[j];
                    }
                    else
                    {

                        float shifted_element = signal2[0];
                        for (int j = 0; j < signal2.Count - 1; j++)
                        {
                            signal2[j] = signal2[j + 1];
                            sum += signal2[j] * signal1[j];
                        }
                        signal2[signal2.Count - 1] = shifted_element;
                        sum += signal2[signal2.Count - 1] * signal1[signal1.Count - 1];
                    }
                    correlation.Add((float)sum / signal2.Count);
                }

            }
            else
            {
                for (int i = 0; i < signal2.Count; i++)
                {
                    double sum = 0;
                    if (i == 0)
                    {
                        for (int j = 0; j < signal2.Count; j++)
                            sum += signal1[j] * signal2[j];
                    }
                    else
                    {
                        for (int j = 0; j < signal2.Count - 1; j++)
                        {
                            signal2[j] = signal2[j + 1];
                            sum += signal2[j] * signal1[j];
                        }
                        signal2[signal2.Count - 1] = 0;
                        sum += signal2[signal2.Count - 1] * signal1[signal1.Count - 1];
                    }
                    correlation.Add((float)sum / signal2.Count);
                }
            }

            OutputNonNormalizedCorrelation = correlation;

            for (int i = 0; i < OutputNonNormalizedCorrelation.Count; i++)
                OutputNormalizedCorrelation.Add((float)(OutputNonNormalizedCorrelation[i] / normalization));
        }

    }
}