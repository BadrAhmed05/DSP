﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class DiscreteFourierTransform : Algorithm
    {
        public Signal InputTimeDomainSignal { get; set; }
        public float InputSamplingFrequency { get; set; }
        public Signal OutputFreqDomainSignal { get; set; }

        public override void Run()
        {
            List<float> F = new List<float>();
            List<float> A = new List<float>();
            List<float> Phase = new List<float>();

            int c = InputTimeDomainSignal.Samples.Count;
            OutputFreqDomainSignal = new Signal(InputTimeDomainSignal.Samples, false, F, A, Phase);
            

            for (int i = 0; i < c; i++)
            {

                float r_part = 0;
                float i_part = 0;
                for (int n = 0; n < c; n++)
                {
                    r_part += InputTimeDomainSignal.Samples[n] * ((float)Math.Cos((i * 2 * Math.PI * n / c)));

                    i_part += -1 * InputTimeDomainSignal.Samples[n] * ((float)Math.Sin((i * 2 * Math.PI * n / c)));
                }
                float amp = (float)(Math.Sqrt(Math.Pow(r_part, 2) + Math.Pow(i_part, 2)));
                OutputFreqDomainSignal.FrequenciesAmplitudes.Add(amp);
                OutputFreqDomainSignal.FrequenciesPhaseShifts.Add((float)Math.Atan2(i_part, r_part));
                float w = (float)(2 * Math.PI) / (c * (1 / InputSamplingFrequency));
                float x = w * (i + 1);
                OutputFreqDomainSignal.Frequencies.Add(x);
            }
        }
    }
}
