﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class Normalizer : Algorithm
    {
        public Signal InputSignal { get; set; }
        public float InputMinRange { get; set; }
        public float InputMaxRange { get; set; }
        public Signal OutputNormalizedSignal { get; set; }

        public override void Run()
        {
            // float x;
            List<float> result = new List<float>();
            // OutputSignal = new Signal(result);
            for (int i = 0; i < InputSignal.Samples.Count; i++)
            {
                float a = InputSignal.Samples.Min();
                float b = InputSignal.Samples.Max();
                float x = (InputMaxRange - InputMinRange) * ((InputSignal.Samples[i] - a) / (b - a)) + InputMinRange;
                result.Add(x);
            }

            OutputNormalizedSignal = new Signal(result, false);
        }
    }
}
