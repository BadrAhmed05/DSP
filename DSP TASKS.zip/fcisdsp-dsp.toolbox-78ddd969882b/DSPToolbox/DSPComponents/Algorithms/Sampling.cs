﻿using DSPAlgorithms.DataStructures;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPAlgorithms.Algorithms
{
    public class Sampling : Algorithm
    {
        public int L { get; set; } //upsampling factor
        public int M { get; set; } //downsampling factor
        public Signal InputSignal { get; set; }
        public Signal OutputSignal { get; set; }
        public override void Run()
        {
            List<float> output_up = new List<float>();
            List<int> index_up = new List<int>();
            List<float> up = new List<float>();
            List<float> down = new List<float>();
            Signal tempSig;
            Signal filteredSig;
            FIR Filter;
            Filter = new FIR();
            Filter.InputFilterType = DSPAlgorithms.DataStructures.FILTER_TYPES.LOW;
            Filter.InputFS = 8000;
            Filter.InputStopBandAttenuation = 50;
            Filter.InputCutOffFrequency = 1500;
            Filter.InputTransitionBand = 500;
            //If M = 0 & L ≠ 0 then up sample by L factor and then apply low pass filter.
            if (M == 0 && L != 0)
            {
                for (int i = 0; i < InputSignal.Samples.Count; i++)
                {
                    up.Add(InputSignal.Samples[i]);
                    for (int j = 0; j < L - 1; j++)
                    {
                        up.Add(0);
                    }
                }

                tempSig = new Signal(up, false);
                Filter.InputTimeDomainSignal = tempSig;
                Filter.Run();
                filteredSig = Filter.OutputYn;
                for (int i = 0; i < filteredSig.Samples.Count - 1; i++)
                {
                    output_up.Add(filteredSig.Samples[i]);
                    index_up.Add(filteredSig.SamplesIndices[i]);
                }

                OutputSignal = new Signal(output_up, index_up, false);
            }
            //If M ≠ 0 & L = 0 then apply filter first and thereafter down sample by M factor.
            else if (M != 0 && L == 0)
            {
                tempSig = new Signal(up, false);
                Filter.InputTimeDomainSignal = InputSignal;
                Filter.Run();
                filteredSig = Filter.OutputYn;
                for (int i = 0; i < filteredSig.Samples.Count; i += M)
                {
                    down.Add(filteredSig.Samples[i]);
                }
                OutputSignal = new Signal(down, false);

            }
            //If M ≠ 0 & L ≠ 0 this means we want to change sample rate by fraction.Thus, first up sample by L factor, apply low pass filter and then down sample by M factor.
            else if (M != 0 && L != 0)
            {
                for (int i = 0; i < InputSignal.Samples.Count; i++)
                {
                    up.Add(InputSignal.Samples[i]);
                    for (int j = 0; j < L - 1; j++)
                    {
                        up.Add(0);
                    }
                }
                tempSig = new Signal(up, false);
                Filter.InputTimeDomainSignal = tempSig;
                Filter.Run();
                filteredSig = Filter.OutputYn;

                for (int i = 0; i < filteredSig.Samples.Count - 1; i += M)
                {
                    down.Add(filteredSig.Samples[i]);
                }
                OutputSignal = new Signal(down, false);
            }
            //If M = 0 & L = 0 then return error message.
            else if (M == 0 && L == 0)
            {
                Console.WriteLine("error");
            }

        }
    }

}