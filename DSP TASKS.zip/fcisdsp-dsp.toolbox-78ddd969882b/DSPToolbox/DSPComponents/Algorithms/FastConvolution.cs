﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class FastConvolution : Algorithm
    {
        public Signal InputSignal1 { get; set; }
        public Signal InputSignal2 { get; set; }
        public Signal OutputConvolvedSignal { get; set; }

        /// <summary>
        /// Convolved InputSignal1 (considered as X) with InputSignal2 (considered as H)
        /// </summary>
        public int getStart(int i)
        {
            if (i < InputSignal1.Samples.Count)
                return 0;
            else
                return (i - InputSignal1.Samples.Count + 1);

        }
        public int getEnd(int i)
        {
            if (i < InputSignal2.Samples.Count)
                return i;
            else
                return (InputSignal2.Samples.Count - 1);

        }
        public override void Run()
        {
            int outputLength = InputSignal1.Samples.Count + InputSignal2.Samples.Count - 1;
            List<float> cov = new List<float>();
            List<int> indx = new List<int>();
            int id = InputSignal1.SamplesIndices[0] + InputSignal2.SamplesIndices[0];

            for (int i = 0; i < outputLength; i++)
            {
                float sum = 0;
                for (int k = getStart(i); k <= getEnd(i); k++)
                {

                    sum += InputSignal1.Samples[i - k] * InputSignal2.Samples[k];
                }
                if (sum == 0 && i + 1 == outputLength)
                {
                    break;
                }
                cov.Add(sum);
                indx.Add(id);
                id += 1;
            }

            OutputConvolvedSignal = new Signal(cov, indx, false);
        }
    }
}
