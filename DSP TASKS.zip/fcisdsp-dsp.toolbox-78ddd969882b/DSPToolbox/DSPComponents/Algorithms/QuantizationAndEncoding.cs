﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class QuantizationAndEncoding : Algorithm
    {
        // You will have only one of (InputLevel or InputNumBits), the other property will take a negative value
        // If InputNumBits is given, you need to calculate and set InputLevel value and vice versa
        public int InputLevel { get; set; }
        public int InputNumBits { get; set; }
        public Signal InputSignal { get; set; }
        public Signal OutputQuantizedSignal { get; set; }
        public List<int> OutputIntervalIndices { get; set; }
        public List<string> OutputEncodedSignal { get; set; }
        public List<float> OutputSamplesError { get; set; }

        public override void Run()
        {

            // levels to bits and vice versa
            int levels_num = 0, bits_num = 0;
            if (InputLevel == 0)
            {
                bits_num = InputNumBits;
                levels_num = (int)Math.Pow(2, bits_num);
            }
            else if (InputNumBits == 0)
            {
                levels_num = InputLevel;
                bits_num = (int)Math.Log(levels_num, 2);
            }

            //calculating delta
            float delta = 0.0F;
            float max = InputSignal.Samples.Max();
            float min = InputSignal.Samples.Min();
            delta = (max - min) / levels_num;

            //calculating the intervals = #L
            List<float> intervals = new List<float>();
            intervals.Add(min);
            for (int i = 0; i < levels_num; i++)
            {
                intervals.Add(intervals[i] + delta);
            }
            // calculating the mid points list
            List<float> midPoints = new List<float>();
            for (int i = 0; i < levels_num; i++)
            {
                midPoints.Add((intervals[i] + intervals[i + 1]) / 2);
            }
            // calculating the quantized list and IntervalIndices
            List<float> QuantizedSignal = new List<float>();
            List<int> encode_decimal = new List<int>();
            for (int i = 0; i < InputSignal.Samples.Count(); i++)
            {
                for (int j = 0; j < intervals.Count(); j++)
                {
                    if (InputSignal.Samples[i] == max)
                    {
                        encode_decimal.Add(levels_num);
                        QuantizedSignal.Add(midPoints[levels_num - 1]);
                        break;
                    }
                    if (InputSignal.Samples[i] >= intervals[j] && InputSignal.Samples[i] <= intervals[j + 1])
                    {
                        encode_decimal.Add(j + 1);
                        QuantizedSignal.Add(midPoints[j]);
                        break;
                    }
                }

            }
            // calculating the encoded signal
            List<string> encode_binary = new List<string>();
            for (int i = 0; i < encode_decimal.Count(); i++)
            {
                encode_binary.Add((Convert.ToString(encode_decimal[i] - 1, 2)).PadLeft(bits_num, '0'));
            }
            //calculating the error sample
            List<float> error = new List<float>();
            for (int k = 0; k < InputSignal.Samples.Count(); k++)
            {
                error.Add(QuantizedSignal[k] - InputSignal.Samples[k]);
            }


            OutputIntervalIndices = encode_decimal;
            OutputQuantizedSignal = new Signal(QuantizedSignal, false);
            OutputEncodedSignal = encode_binary;
            OutputSamplesError = error;

        }
    }
}
