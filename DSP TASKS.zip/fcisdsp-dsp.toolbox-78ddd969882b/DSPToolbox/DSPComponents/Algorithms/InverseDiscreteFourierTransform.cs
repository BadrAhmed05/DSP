﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using DSPAlgorithms.DataStructures;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace DSPAlgorithms.Algorithms
{
    public class InverseDiscreteFourierTransform : Algorithm
    {
        public Signal InputFreqDomainSignal { get; set; }
        public Signal OutputTimeDomainSignal { get; set; }

        public override void Run()
        {
            List<float> ph = new List<float>();
            List<float> am = new List<float>();
            List<Complex> dft = new List<Complex>();
            List<float> result = new List<float>();
            //OutputTimeDomainSignal = new Signal(InputFreqDomainSignal.Samples, false, F, A, Phase);
            am= new List<float>(InputFreqDomainSignal.FrequenciesAmplitudes);
            ph=new List<float>(InputFreqDomainSignal.FrequenciesPhaseShifts);
            int N = InputFreqDomainSignal.FrequenciesAmplitudes.Count;
            for (int i = 0; i < InputFreqDomainSignal.FrequenciesAmplitudes.Count; i++)
            {
                Complex x = 0;
                float y= 0;
                for(int n=0; n<InputFreqDomainSignal.FrequenciesAmplitudes.Count; n++)
                {
                    Complex a = Complex.FromPolarCoordinates(am[n], ph[n]) ;
                    x += a * Complex.Exp(Complex.ImaginaryOne * 2 * Math.PI * n * i / InputFreqDomainSignal.FrequenciesAmplitudes.Count);
                }
                x = x / InputFreqDomainSignal.FrequenciesAmplitudes.Count;
                result.Add((float)x.Real);


            }
            OutputTimeDomainSignal = new Signal(result, false);

        }
    }
}
