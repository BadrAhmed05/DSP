﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPAlgorithms.DataStructures
{
    public enum FILTER_TYPES
    {
        LOW, HIGH, BAND_PASS, BAND_STOP
    }
}
